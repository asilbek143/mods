# UzTrajectory - Tushish Nazari

PvP paytida **Ender Pearl, Trident, Snowball, Egg, Splash/Lingering Potion va O'q (Bow/Crossbow)**
qayerga tushishini oldindan chiziq va "X" belgisi bilan ko'rsatadigan Fabric client mod.

Mod faqat **client-side** ishlaydi (serverga o'rnatish shart emas) — faqat sen tomonda
otiladigan narsani qo'lingga olsang yoki yoy tortsang, avtomatik trayektoriya chizig'i chiqadi.

## Nima kerak (build qilishdan oldin)

1. **JDK 17** o'rnatilgan bo'lishi kerak (`java -version` bilan tekshir).
2. IntelliJ IDEA (Community versiyasi ham bo'ladi) yoki VS Code + Java kengaytmasi.
3. Internetga ulanish (Gradle Minecraft, mappings va Fabric API'ni yuklab oladi).

## Qanday build qilish

1. `uztrajectory` papkasini IntelliJ IDEA'da **Gradle loyihasi sifatida och** ("Open" -> papkani tanla).
2. IDE avtomatik Gradle sinxronizatsiyasini boshlaydi (birinchi safar 5-15 daqiqa vaqt olishi mumkin,
   chunki Minecraft va kutubxonalar yuklab olinadi).
3. Terminalda loyiha papkasida quyidagini ishga tushir:

```bash
./gradlew build
```

(Windows'da: `gradlew.bat build`)

4. Build tugagach, tayyor `.jar` fayl shu yerda bo'ladi:

```
build/libs/uztrajectory-1.0.0.jar
```

## Qanday o'rnatish

1. Minecraft **1.20.1** uchun **Fabric Loader** o'rnatilgan bo'lishi kerak.
2. **Fabric API** mod'ini yuklab, `.minecraft/mods` papkasiga qo'y (bu mod shunga bog'liq).
3. `uztrajectory-1.0.0.jar` faylni ham xuddi shu `mods` papkasiga ko'chir.
4. O'yinni ishga tushir — Fabric profili orqali.

## Ishlatish

- Qo'lingga Ender Pearl, Trident, Snowball, Egg yoki Splash/Lingering Potion olsang —
  trayektoriya avtomatik chiqadi.
- Yoy (Bow) tortsang yoki Arbalet (Crossbow) zaryadlangan bo'lsa — o'qning yo'li ko'rinadi.
- **O** tugmasi — mod'ni butunlay yoqish/o'chirish (chatda xabar chiqadi).

## Agar build xato bersa

`gradle.properties` faylidagi versiyalar (`loader_version`, `yarn_mappings`, `fabric_version`,
va `build.gradle`'dagi `fabric-loom` versiyasi) vaqt o'tishi bilan eskirishi mumkin.
Shunday holatda https://fabricmc.net/develop saytiga kirib, **Minecraft 1.20.1** ni tanlab,
u yerda ko'rsatilgan eng so'nggi mos versiyalarni shu fayllarga qo'yib qayta urinib ko'r.
