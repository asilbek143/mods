package uz.uzcraft.uztrajectory;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

public final class TrajectoryRenderer {

    private TrajectoryRenderer() {
    }

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(TrajectoryRenderer::onRender);
    }

    private static void onRender(WorldRenderContext context) {
        if (!UzTrajectoryClient.enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) return;

        ThrowDetector.Detected detected = ThrowDetector.detect(player);
        if (detected == null) return;

        TrajectorySimulator.Result result = TrajectorySimulator.simulate(
                client.world, player, detected.type, detected.speed
        );

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        Vec3d cameraPos = context.camera().getPos();

        matrices.push();
        matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

        int color = detected.type.color;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.lineWidth(3.0F);

        drawLine(matrices, result.points, r, g, b);
        drawLandingMarker(matrices, result.landingPoint, r, g, b);

        RenderSystem.lineWidth(1.0F);
        RenderSystem.disableBlend();

        matrices.pop();
    }

    private static void drawLine(MatrixStack matrices, List<Vec3d> points, float r, float g, float b) {
        if (points.size() < 2) return;

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        buffer.begin(VertexFormat.DrawMode.LINE_STRIP, VertexFormats.POSITION_COLOR);

        for (Vec3d p : points) {
            buffer.vertex(matrix, (float) p.x, (float) p.y, (float) p.z)
                    .color(r, g, b, 0.9f)
                    .next();
        }
        Tessellator.getInstance().draw();
    }

    private static void drawLandingMarker(MatrixStack matrices, Vec3d pos, float r, float g, float b) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        buffer.begin(VertexFormat.DrawMode.LINES, VertexFormats.POSITION_COLOR);

        float s = 0.35f;
        float y = (float) pos.y + 0.02f;
        float x = (float) pos.x;
        float z = (float) pos.z;

        // Tushish nuqtasida "X" belgisi
        vertex(buffer, matrix, x - s, y, z - s, r, g, b);
        vertex(buffer, matrix, x + s, y, z + s, r, g, b);
        vertex(buffer, matrix, x - s, y, z + s, r, g, b);
        vertex(buffer, matrix, x + s, y, z - s, r, g, b);

        // Ko'rinishni yaxshilash uchun tepaga qarab kichik chiziq
        vertex(buffer, matrix, x, y, z, r, g, b);
        vertex(buffer, matrix, x, y + 1.0f, z, r, g, b);

        Tessellator.getInstance().draw();
    }

    private static void vertex(BufferBuilder buffer, Matrix4f matrix, float x, float y, float z, float r, float g, float b) {
        buffer.vertex(matrix, x, y, z).color(r, g, b, 0.9f).next();
    }
}
