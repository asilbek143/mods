package uz.uzcraft.uztrajectory;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.util.Hand;

/**
 * O'yinchi qaysi qo'lida (asosiy yoki yordamchi) nima ushlab turganini tekshiradi
 * va agar bu trayektoriya ko'rsatilishi kerak bo'lgan narsa bo'lsa, qaytaradi.
 */
public final class ThrowDetector {

    private ThrowDetector() {
    }

    public static final class Detected {
        public final ProjectileType type;
        /** -1 bo'lsa, ProjectileType.baseSpeed ishlatiladi (masalan yoy uchun dinamik tezlik kerak) */
        public final float speed;

        Detected(ProjectileType type, float speed) {
            this.type = type;
            this.speed = speed;
        }
    }

    public static Detected detect(ClientPlayerEntity player) {
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getStackInHand(hand);
            Item item = stack.getItem();

            // Yoy tortilayotgan bo'lsa - tortish darajasiga qarab tezlik hisoblanadi
            if (item instanceof BowItem && player.isUsingItem() && player.getActiveHand() == hand) {
                int useTicks = stack.getMaxUseTime() - player.getItemUseTimeLeft();
                float pull = BowItem.getPullProgress(useTicks);
                if (pull >= 0.1f) {
                    return new Detected(ProjectileType.ARROW, pull * 3.0f);
                }
            }

            // Arbalet (crossbow) to'liq zaryadlangan bo'lsa - istalgan payt otishga tayyor
            if (item instanceof CrossbowItem && CrossbowItem.isCharged(stack)) {
                return new Detected(ProjectileType.ARROW, 3.15f);
            }

            if (item == Items.ENDER_PEARL) return new Detected(ProjectileType.ENDER_PEARL, -1);
            if (item == Items.SNOWBALL) return new Detected(ProjectileType.SNOWBALL, -1);
            if (item == Items.EGG) return new Detected(ProjectileType.EGG, -1);
            if (item == Items.TRIDENT) return new Detected(ProjectileType.TRIDENT, -1);
            // Faqat otiladigan (splash/lingering) potion, ichiladigani emas
            if (item instanceof SplashPotionItem) return new Detected(ProjectileType.POTION, -1);
        }
        return null;
    }
}
