package uz.uzcraft.uztrajectory;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Vanilla Minecraft'dagi ProjectileEntity.tick() mantig'iga o'xshash tarzda,
 * har tikda: pozitsiya += tezlik; tezlik *= drag; tezlik.y -= gravity.
 * Bu aniq fizika emas, lekin ko'z bilan ko'rish uchun yetarlicha to'g'ri taxmin.
 */
public final class TrajectorySimulator {

    private static final int MAX_STEPS = 140; // taxminan 7 soniyalik parvoz
    private static final double MAX_DISTANCE_SQ = 130.0 * 130.0;

    private TrajectorySimulator() {
    }

    public static final class Result {
        public final List<Vec3d> points;
        public final Vec3d landingPoint;
        public final boolean hit;

        Result(List<Vec3d> points, Vec3d landingPoint, boolean hit) {
            this.points = points;
            this.landingPoint = landingPoint;
            this.hit = hit;
        }
    }

    public static Result simulate(World world, ClientPlayerEntity player, ProjectileType type, float speedOverride) {
        Vec3d start = player.getEyePos();
        float pitch = player.getPitch() + type.pitchOffset;
        float yaw = player.getYaw();

        double pitchRad = Math.toRadians(pitch);
        double yawRad = Math.toRadians(yaw);

        double dx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double dy = -Math.sin(pitchRad);
        double dz = Math.cos(yawRad) * Math.cos(pitchRad);

        float speed = speedOverride > 0 ? speedOverride : type.baseSpeed;
        Vec3d velocity = new Vec3d(dx, dy, dz).multiply(speed);

        List<Vec3d> points = new ArrayList<>();
        Vec3d pos = start;
        points.add(pos);

        for (int i = 0; i < MAX_STEPS; i++) {
            Vec3d next = pos.add(velocity);

            BlockHitResult hitResult = world.raycast(new RaycastContext(
                    pos, next,
                    RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE,
                    player
            ));

            if (hitResult.getType() != HitResult.Type.MISS) {
                points.add(hitResult.getPos());
                return new Result(points, hitResult.getPos(), true);
            }

            pos = next;
            points.add(pos);

            velocity = velocity.multiply(type.drag);
            velocity = velocity.add(0, -type.gravity, 0);

            if (start.squaredDistanceTo(pos) > MAX_DISTANCE_SQ) {
                break;
            }
        }

        return new Result(points, pos, false);
    }
}
