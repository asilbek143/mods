package uz.uzcraft.uztrajectory;

/**
 * Har bir otiladigan narsaning vanilla Minecraft'dagi taxminiy fizika qiymatlari.
 * gravity  - har tikda pastga tortish kuchi
 * drag     - havoda sekinlashish koeffitsienti (har tikda tezlikka ko'paytiriladi)
 * baseSpeed- otilganda boshlang'ich tezlik
 * pitchOffset - ba'zi narsalar (masalan potion) balandroq uchadi, shuning uchun pitch'ga qo'shiladi
 * color    - chiziq rangi (0xRRGGBB)
 */
public enum ProjectileType {
    ENDER_PEARL(0.03f, 0.99f, 1.5f, 0f, 0xE23FE2),
    SNOWBALL(0.03f, 0.99f, 1.5f, 0f, 0xFFFFFF),
    EGG(0.03f, 0.99f, 1.5f, 0f, 0xE8D6A0),
    POTION(0.05f, 0.99f, 0.5f, -20f, 0x30C8FF),
    TRIDENT(0.05f, 0.99f, 2.5f, 0f, 0x2CFFC2),
    ARROW(0.05f, 0.99f, 3.0f, 0f, 0xFFE14D);

    public final float gravity;
    public final float drag;
    public final float baseSpeed;
    public final float pitchOffset;
    public final int color;

    ProjectileType(float gravity, float drag, float baseSpeed, float pitchOffset, int color) {
        this.gravity = gravity;
        this.drag = drag;
        this.baseSpeed = baseSpeed;
        this.pitchOffset = pitchOffset;
        this.color = color;
    }
}
