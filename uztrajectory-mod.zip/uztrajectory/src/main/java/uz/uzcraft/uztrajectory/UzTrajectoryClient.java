package uz.uzcraft.uztrajectory;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class UzTrajectoryClient implements ClientModInitializer {

    public static final String MOD_ID = "uztrajectory";

    /** Mod default holatda yoqilgan. "O" tugmasi bilan yoqish/o'chirish mumkin. */
    public static boolean enabled = true;

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.uztrajectory.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "category.uztrajectory"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal(enabled
                                    ? "\u00a7a[UzTrajectory] Yoqildi"
                                    : "\u00a7c[UzTrajectory] O'chirildi"),
                            true
                    );
                }
            }
        });

        TrajectoryRenderer.register();
    }
}
